# PAIL Core (tampered)
